/*
 * Automated File Retrieval
 * Copyright (C) 2003 Bailey Kong
 *
 * This file is part of Automated File Retrieval (AFR).
 *
 * AFR is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * AFR is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with AFR; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#define _GNU_SOURCE
#include <string.h>
#include "afr.h"
#include "checksum.h"
#include "utils.h"
#include "xchat_get.h"

/* 
 * check_conn checks to see whether there's already an established DCC Chat connection
 * to the current target
 */

int check_conn(struct query *item) {
	if (current->is_dcc)
		return 1;
	
	void *dcclist = xchat_list_get(ph, "dcc");
	if (dcclist) {
		while (xchat_list_next(ph, dcclist)) {
			if (strcasecmp(xchat_list_str(ph, dcclist, "nick"), current->nick) == 0 &&
			    /* DCC Type: 0-Send 1-Receive 2-ChatRecv 3-ChatSend */
			    xchat_list_int(ph, dcclist, "type") == 2 &&
			    /* DCC Status: 0-Queued 1-Active 2-Failed 3-Done 4-Connecting 5-Aborted */
			    xchat_list_int(ph, dcclist, "status") == 1) {
				item->status |= OFFERED_CHAT+ESTABLISHED_CHAT;
				return 1;
			}
		}
	}
	xchat_list_free(ph, dcclist);

	return 0;
}

/*
 * if dcc_auto_chat is not enabled, establish_dccchat establishes DCC Chat connection
 * when a DCC CHAT Offer is received
 */

void establish_dccchat(struct query *item) {
	if (!get_prefs("dcc_auto_chat")) {
		log_printf(2, "debug2: establish_dccchat: dcc chat %s", current->nick);
		xchat_commandf(ph, "dcc chat %s", current->nick);
	}
	log_printf(1, "debug1: Established DCC chat with %s", current->nick);
	item->status |= ESTABLISHED_CHAT;
}

/*
 * if dcc_auto_send is not enabled, establish_dccrecv is needed to establish DCC Send
 * connection when a DCC SEND Connect is received. regardless of dcc_auto_send,
 * establish_dccrecv is needed to store the filename for comparison during dequeue
 */

void establish_dccrecv(struct query *item, const char *filename) {
	if (!get_prefs("dcc_auto_send")) {
		log_printf(2, "debug2: establish_dccrecv: dcc get %s", current->nick);
		xchat_commandf(ph, "dcc get %s", current->nick);
	}
	free(item->filename_requested);
	item->filename_requested = strndup(filename, NAME_MAX);
	if (item->filename_requested == NULL) {
		log_printf(0, "AFR: ERROR: Out of memory.");
	} else {
		if (item->crc32 == NULL) {
			item->crc32 = getr_crc32(filename);
		}
		if (item->md5 == NULL) {
			item->md5 = getr_md5(filename);
		}
		/* make sure we didn't accidentally pick up part of the md5 checksum
		   and said it was a crc32 checksum. */
		if (item->md5 != NULL &&
		    item->crc32 != NULL &&
		    strcasestr(item->md5, item->crc32) != NULL) {
		        free(item->crc32);
			item->crc32 = NULL;
		}
	}
	log_printf(2, "debug2: establish_dccrecv: filename_requested => %s",
		   item->filename_requested);
	log_printf(1, "debug1: Established DCC receive with %s", current->nick);
}

/*
 * offer_dccchat tiggers the fserve to offer a DCC Chat to us
 */

void offer_dccchat(struct query *item) {
	if (strlen(current->channel)) {
		xchat_set_context(ph, get_channel_context(current->channel));
		log_printf(2, "debug2: offer_dccchat: msg %s %s", current->channel, item->command);
		xchat_commandf(ph, "msg %s %s", current->channel, item->command);
	} else {
		xchat_set_context(ph, current->current_context);
		log_printf(2, "debug2: offer_dccchat: ctcp %s %s", current->nick, item->command);
		xchat_commandf(ph, "ctcp %s %s", current->nick, item->command);
	}
	log_printf(1, "debug1: Offering DCC chat with %s", current->nick);
	item->status |= OFFERED_CHAT;
}

/*
 * request_file tries to request a file from the queue on the established DCC Chat connection 
 */

int request_file(struct query *item) {
	int count = 0;
	char *temp_str = NULL;
	xchat_set_context(ph, current->current_context);
	if (current->is_dcc) {
/*
 * REMIND USER TO ADD '#' BEFORE THE NUMBER FOR THE FILENAME
 */
		log_printf(2, "debug2: request_file: xget => ctcp %s %s %s",
			   current->nick,
			   item->command,
			   item->file_id);
		xchat_commandf(ph, "ctcp %s %s %s", current->nick, item->command, item->file_id);
	} else {
		/* send a command to the server to try to obtain info on the max sends
		 * we're borrowing space from the is_dcc var to see if we got it already
		 */
		if (current->is_dcc ^ GOT_MAX_REQUESTS) {
			xchat_commandf(ph, "msg =%s my_queues", current->nick);
		}

		char *temp_dir = strdup(item->directory);
		if (temp_dir == NULL) {
			log_printf(0, "AFR: ERROR: Out of memory.");
			return 0;
		}
		while ((temp_str = strchr(temp_dir, '/')) != NULL) {
			*temp_str++ = '\0';
			log_printf(3, "debug3: request_file: msg =%s cd %s", current->nick, temp_dir);
			xchat_commandf(ph, "msg =%s cd %s", current->nick, temp_dir);
			strcpy(temp_dir, temp_str);
			count++;
		}
		if (strlen(temp_dir)) {
			log_printf(3, "debug3: request_file: msg =%s cd %s", current->nick, temp_dir);
			xchat_commandf(ph, "msg =%s cd %s", current->nick, temp_dir);
			count++;
		}
		log_printf(2, "debug2: request_file: get => msg =%s get %s",
			   current->nick,
			   item->file_id);
		xchat_commandf(ph, "msg =%s get %s", current->nick, item->file_id);
		while (count) {
			log_printf(3, "debug3: request_file: msg =%s cd ..", current->nick);
			xchat_commandf(ph, "msg =%s cd ..", current->nick);
			count--;
		}
		free(temp_dir);
	}
	current->error[0] = '\0';
	log_printf(1, "debug1: Requested ->%s<- from %s", item->file_id, current->nick);

	/* successfully requested the file from the server */
	return REQUESTED_FILE;
}
