/*
 * Automated File Retrieval
 * Copyright (C) 2003 Bailey Kong
 *
 * This file is part of Automated File Retrieval (AFR).
 *
 * AFR is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * AFR is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with AFR; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "afr.h"
#include "event_handlers.h"
#include "user_commands.h"

int xchat_plugin_init(xchat_plugin *plugin_handle,
		      char **plugin_name,
		      char **plugin_desc,
		      char **plugin_version,
		      char *arg) {

	static int cn[3] = {1, 2, 10};
	static int jo[3] = {1, 2, 11};
	static int qu[3] = {1, 2, 12};
	static int pc[3] = {0, 0, 13};
	/* we need to save this for use with any xchat_* functions */
	ph = plugin_handle;

	*plugin_name = PLUGIN_NAME;
	*plugin_desc = PLUGIN_DESC;
	*plugin_version = PLUGIN_VERS;

	xchat_hook_command(ph, "afr-crc32", XCHAT_PRI_NORM, crc32_cb,
			   "Usage: afr-crc32 <requestid> <crc32>", NULL);
	xchat_hook_command(ph, "afr-debug", XCHAT_PRI_NORM, debug_cb,
			   "Usage: afr-debug <0|1|2|3>", NULL);
	xchat_hook_command(ph, "afr-enqueue", XCHAT_PRI_NORM, enqueue_cb,
			   "Usage: afr-enqueue \"<filename>\" \"<command>\" <channel>", NULL);
	xchat_hook_command(ph, "afr-help", XCHAT_PRI_NORM, help_cb,
			   "Usage: afr-help", NULL);
	xchat_hook_command(ph, "afr-list", XCHAT_PRI_NORM, list_cb,
			   "Usage: afr-list", NULL);
	xchat_hook_command(ph, "afr-load", XCHAT_PRI_NORM, load_cb,
			   "Usage: afr-load <filename>", NULL);
	xchat_hook_command(ph, "afr-md5", XCHAT_PRI_NORM, md5_cb,
			   "Usage: afr-md5 <requestid> <md5>", NULL);
	xchat_hook_command(ph, "afr-next", XCHAT_PRI_NORM, next_cb,
			   "Usage: afr-next", NULL);
	xchat_hook_command(ph, "afr-remove", XCHAT_PRI_NORM, remove_cb,
			   "Usage: afr-remove <requestid>", NULL);
	xchat_hook_command(ph, "afr-save", XCHAT_PRI_NORM, save_cb,
			   "Usage: afr-save <filename>", NULL);
	xchat_hook_command(ph, "afr-target", XCHAT_PRI_NORM, target_cb,
			   "Usage: afr-target <nick>", NULL);
	xchat_hook_command(ph, "afr-toggle", XCHAT_PRI_NORM, toggle_plugin_cb,
			   "Usage: afr-toggle <on|off>", NULL);
	xchat_hook_command(ph, "afr-toggle-checksum", XCHAT_PRI_NORM, toggle_checksum_cb,
			   "Usage: afr-toggle-checksum <on|off>", NULL);
	xchat_hook_print(ph, "Change Nick", XCHAT_PRI_NORM, eyes_cb, cn);
	xchat_hook_print(ph, "Join", XCHAT_PRI_NORM, eyes_cb, jo);
	xchat_hook_print(ph, "Quit", XCHAT_PRI_NORM, eyes_cb, qu);
	xchat_hook_timer(ph, 60000, pump_cb, pc);

	xchat_printf(ph, "%s loaded successfully!\n", PLUGIN_NAME);
	xchat_print(ph, "AFR: /afr-help for list of commands");

	return 1;  /* return 1 for success */
}

int xchat_plugin_deinit() {
	while (first != NULL) {
		current = first;
		first = first->next;
		destroy_target(current);
	}
	xchat_printf(ph, "%s unloaded successfully!\n", PLUGIN_NAME);

	return 1;  /* return 1 for success */
}
