/*
 * Automated File Retrieval
 * Copyright (C) 2003 Bailey Kong
 *
 * This file is part of Automated File Retrieval (AFR).
 *
 * AFR is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * AFR is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with AFR; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <ctype.h>
#include <pthread.h>
#include <stdio.h>
#define __USE_GNU
#include <string.h>
#include <openssl/md5.h>
#include <zlib.h>
#include "afr.h"
#include "manage_list_lock.h"
#include "utils.h"

char *crc32_checksum(const char *filename) {
	FILE *file_ptr = NULL;
	file_ptr = wc_fopen(filename, "r");
	if (file_ptr == NULL) {
		log_printf(1, "debug1: crc32_checksum: %s can not be opened for reading.",
			   filename);
		return NULL;
	}

	uLong crc = crc32(0L, Z_NULL, 0);
	while ( !feof(file_ptr) ) {
		unsigned char databuf[BUFSIZ];
		size_t read_bytes = fread(&databuf, 1, BUFSIZ, file_ptr);
		if ( ferror(file_ptr) ) {
			log_printf(1, "debug1: crc32_checksum: file_ptr error");
			fclose(file_ptr);
			return NULL;
		}
		crc = crc32(crc, databuf, read_bytes);
	}
	fclose(file_ptr);

	char *checksum = malloc(sizeof(char)*9);
	if (checksum == NULL) {
		log_printf(0, "AFR: ERROR: Out of memory.");
		return NULL;
	}
	*checksum = '\0';
	sprintf(checksum, "%08x", (unsigned int)crc);
	log_printf(2, "debug2: crc32_checksum: %s %s", checksum, filename);
	return checksum;
}

char *md5_checksum(const char *filename) {
	FILE *file_ptr = NULL;
	file_ptr = wc_fopen(filename, "r");
	if (file_ptr == NULL) {
		log_printf(1, "debug1: md5_checksum: %s can not be opened for reading.",
			   filename);
		return NULL;
	}
	MD5_CTX ctx;
	MD5_Init(&ctx);
	while ( !feof(file_ptr) ) { 
		unsigned char databuf[BUFSIZ]; 
		size_t read_bytes = fread(&databuf, 1, BUFSIZ, file_ptr); 
		if ( ferror(file_ptr) ) { 
			log_printf(1, "debug1: md5_checksum: file_ptr error");
			fclose(file_ptr);
			return NULL;
		} 
		MD5_Update(&ctx, databuf, read_bytes); 
	}
	fclose(file_ptr);
	unsigned char md[MD5_DIGEST_LENGTH];
	MD5_Final(md, &ctx);
   
	char *checksum = malloc(sizeof(char)*33);
	if (checksum == NULL) {
		log_printf(0, "AFR: ERROR: Out of memory.");
		return NULL;
	}
	*checksum = '\0';

	int index;
	char md_value[3];
	for (index = 0; index < MD5_DIGEST_LENGTH; ++index) {
		sprintf(md_value, "%02x", md[index]);
		strcat(checksum, md_value);
	}
	log_printf(2, "debug2: md5_checksum: %s %s", checksum, filename);

	return checksum;
}

int compare_crc32(const char *filename, const char *crc32) {
	if (crc32 == NULL || *crc32 == '\0') {
		return 1;
	} else {
		char *checksum = crc32_checksum(filename);
		if (checksum == NULL) {
			return 0; 
		} else {
			if (strcasecmp(crc32, checksum)) {
				free(checksum);
				return 0;
			} else {
				free(checksum);
				return 1;
			}
		}

	}
}

int compare_md5(const char *filename, const char *md5) {
	if (md5 == NULL || *md5 == '\0') {
		return 1;
	} else {
		char *checksum = md5_checksum(filename);
		if (checksum == NULL) {
			return 0; 
		} else {
			if (strcasecmp(md5, checksum)) {
				free(checksum);
				return 0;
			} else {
				free(checksum);
				return 1;
			}
		}

	}
}

void *checksum(void *arg) {
	static pthread_mutex_t checksum_mutex = PTHREAD_MUTEX_INITIALIZER;
	struct to_thread *thread_item = arg;

	if (pthread_mutex_lock(&checksum_mutex)) {
		destroy_query(thread_item->item);
		free(thread_item);
		pthread_exit(NULL);
	}

	if (compare_crc32(thread_item->item->dest_filename, thread_item->item->crc32) &&
	    compare_md5(thread_item->item->dest_filename, thread_item->item->md5)) {
		if (thread_item->item->crc32 != NULL)
			log_printf(1, "debug1: checksum: %s passed checksum. (crc32: %s)",
				   thread_item->item->dest_filename,
				   thread_item->item->crc32);
		if (thread_item->item->md5 != NULL)
			log_printf(1, "debug1: checksum: %s passed checksum. (md5: %s)",
				   thread_item->item->dest_filename,
				   thread_item->item->md5);
		destroy_query(thread_item->item);
	} else {
		if (thread_item->item->crc32 != NULL)
			log_printf(1, "debug1: checksum: %s failed checksum. Expected crc32: %s",
				   thread_item->item->dest_filename,
				   thread_item->item->crc32);
		if (thread_item->item->md5 != NULL)
			log_printf(1, "debug1: checksum: %s failed checksum. Expected md5: %s",
				   thread_item->item->dest_filename,
				   thread_item->item->md5);

		free(thread_item->item->dest_filename);
		thread_item->item->dest_filename = NULL;
		thread_item->item->status = 0;
		if (manage_list_lock(LOCK_LIST)) {
			struct target *temp_list = first;
			while (temp_list != NULL && temp_list != thread_item->target)
				temp_list = temp_list->next;
			if (temp_list != NULL) {
				thread_item->item->next = thread_item->target->head;
				thread_item->target->head = thread_item->item;
				if (thread_item->target->tail == NULL)
					thread_item->target->tail = thread_item->target->head;
			} else
				destroy_query(thread_item->item);

			manage_list_lock(UNLOCK_LIST);
		}
	}

	pthread_mutex_unlock(&checksum_mutex);
	free(thread_item);
	pthread_exit(NULL);
}

/*
 * get_hex_string starts looking for a hex string of length at the start of the string
 */

char *get_hex_string(const char *string, int length) {
	int count = 0;
	int index;
	int str_length = strlen(string);
	for (index = 0; index < str_length; index++) {
		if (isxdigit(string[index])) {
			count++;
		} else
			count = 0;

		if (count == length)
			return strndup(string+index-length+1, length);
	}
	return NULL;
}

/*
 * getr_hex_string starts looking for a hex string of length at the end of the string
 */

char *getr_hex_string(const char *string, int length) {
	int count = 0;
	int index;
	for (index = strlen(string)-1; index >= 0; index--) {
		if (isxdigit(string[index])) {
			count++;
		} else
			count = 0;

		if (count == length)
			return strndup(string+index, length);
	}
	return NULL;
}

char *get_crc32(const char *string) {
	return get_hex_string(string, 8);
}

char *getr_crc32(const char *string) {
	return getr_hex_string(string, 8);
}

char *get_md5(const char *string) {
	return get_hex_string(string, 32);
}

char *getr_md5(const char *string) {
	return getr_hex_string(string, 32);
}

int is_crc32(const char *crc32) {
	if (strlen(crc32) == 8) {
		char *temp = NULL;
		if ((temp = get_crc32(crc32)) != NULL) {
			free(temp);
			return 1;
		}
	}
	return 0;
}

int is_md5(const char *md5) {
	if (strlen(md5) == 32) {
		char *temp = NULL;
		if ((temp = get_md5(md5)) != NULL) {
			free(temp);
			return 1;
		}
	}
	return 0;
}
