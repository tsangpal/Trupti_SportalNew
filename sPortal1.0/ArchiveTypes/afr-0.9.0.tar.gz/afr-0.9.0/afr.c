/*
 * Automated File Retrieval
 * Copyright (C) 2003 Bailey Kong
 *
 * This file is part of Automated File Retrieval (AFR).
 *
 * AFR is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * AFR is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with AFR; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#define _GNU_SOURCE
#include <string.h>
#include "afr.h"
#include "brain.h"
#include "utils.h"

xchat_plugin *ph;   /* plugin handle */
int target_count = 0;
int debug_level = -1; /* -1 = OFF */
int use_checksum = 1;

struct target *current = NULL;  /* Pointer to the list */
struct target *first = NULL;  /* Pointer to the beginning of the list */

struct query *create_query(const char *u_command, const char *u_directory, const char *u_fileid) {
	struct query *new = malloc(sizeof(struct query));
	if (new == NULL) {
		log_printf(0, "AFR: ERROR: Out of memory.");
	} else {
		new->command = strdup(u_command);
		new->directory = strdup(u_directory);
		new->file_id = strdup(u_fileid);
		new->filename_requested = NULL;
		new->dest_filename = NULL;
		new->status = 0;
		new->completed_ts = 0;
		new->crc32 = NULL;
		new->md5 = NULL;
		new->next = NULL;
		if (new->command == NULL || new->directory == NULL || new->file_id == NULL) {
			destroy_query(new);
			new = NULL;
		}
	}
	return new;
}

struct target *create_target(const char *u_nick, xchat_context *u_context) {
	struct target *new = malloc(sizeof(struct target));
	if (new == NULL) {
		log_printf(0, "AFR: ERROR: Out of memory.");
	} else {
		new->nick = strndup(u_nick, NICK_MAX);
		new->channel = NULL;
		new->is_dcc = 0;
		new->max_requests = 1;
		new->error[0] = '\0';
		new->error_timeout = 0;
		new->current_context = u_context;
		new->head = NULL;
		new->tail = NULL;
		new->next = NULL;
	}
	return new;
}

struct to_thread *create_to_thread(struct target *u_target, struct query *u_item) {
	struct to_thread *new = malloc(sizeof(struct to_thread));
	new->target = u_target;
	new->item = u_item;
	return new;
}

void destroy_query(struct query *item) {
	log_printf(3, "debug3: destroy query object: %x", item);
	if (item != NULL) {
		if (item->command != NULL)
			free(item->command);
		if (item->directory != NULL)
			free(item->directory);
		if (item->file_id != NULL)
			free(item->file_id);
		if (item->filename_requested != NULL)
			free(item->filename_requested);
		if (item->dest_filename != NULL)
			free(item->dest_filename);
		if (item->crc32 != NULL)
			free(item->crc32);
		if (item->md5 != NULL)
			free(item->md5);
		free(item);
	}
}

void destroy_target(struct target *target) {
	log_printf(3, "debug3: destroy target object: %x", target);
	if (target != NULL) {
		while (target->head != NULL) {
			target->tail = target->head;
			target->head = target->head->next;
			destroy_query(target->tail);
		}
		free(target->nick);
		if (target->channel != NULL)
			free(target->channel);
		free(target);
	}
}

void enqueue(struct target *target, struct query *item) {
	if (target->head == NULL) {
		target->head = target->tail = item;
	} else {
		target->tail->next = item;
		target->tail = target->tail->next;
	}
}

struct query *remove_query(struct target *target, struct query *item) {
	log_printf(3, "debug3: before: target->head: %x | target->tail: %x", target->head, target->tail);
	if (item == target->head) {
		target->head = target->head->next;
	} else {
		struct query *temp_item = target->head;
		while (temp_item != NULL && temp_item->next != item)
			temp_item = temp_item->next;
		if (temp_item == NULL) {
			return NULL;
		} else {
			temp_item->next = temp_item->next->next;
		}
	}
	log_printf(3, "debug3: target->tail: %x =? item: %x", target->tail, item);
	if (target->tail == item) {
		target->tail = target->head;
		while (target->tail != NULL && target->tail->next != NULL)
			target->tail = target->tail->next;
	}
	item->next = NULL;
	log_printf(3, "debug3: after: target->head: %x | target->tail: %x", target->head, target->tail);
	return item;
}

struct target *remove_target(struct target *target) {
	log_printf(3, "debug3: before: first: %x | current: %x", first, current);
	if (target == first) {
		first = first->next;
	} else {
		struct target *temp_list = first;
		while (temp_list != NULL && temp_list->next != target)
			temp_list = temp_list->next;
		if (temp_list == NULL) {
			return NULL;
		} else {
			temp_list->next = temp_list->next->next;
		}
	}
	log_printf(3, "debug3: current: %x =? target: %x", current, target);
	if (current == target)
		current = first;
	target->next = NULL;
	target_count--;
	log_printf(3, "debug3: after: first: %x | current: %x", first, current);
	return target;
}
