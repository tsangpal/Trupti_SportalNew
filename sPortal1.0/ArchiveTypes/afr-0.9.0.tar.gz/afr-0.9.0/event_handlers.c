/*
 * Automated File Retrieval
 * Copyright (C) 2003 Bailey Kong
 *
 * This file is part of Automated File Retrieval (AFR).
 *
 * AFR is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * AFR is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with AFR; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <stdio.h>
#include <string.h>
#include "afr.h"
#include "brain.h"
#include "manage_list_lock.h"
#include "utils.h"

/*
 * eyes_cb sits and waits for Message/Notify/DCC related Text Events and handles them
 */

int eyes_cb(char *word[], void *userdata) {

	int *index = (int *) userdata;

	char *nick = malloc(sizeof(char));
	if (nick == NULL) {
		log_printf(0, "AFR: ERROR: Out of memory.");
		return XCHAT_EAT_NONE;
	}
	*nick = '\0';

	char *message = malloc(sizeof(char));
	if (message == NULL) {
		free(nick);
		log_printf(0, "AFR: ERROR: Out of memory.");
		return XCHAT_EAT_NONE;
	}
	*message = '\0';

	if (index[0] > 0) {
		free(nick);
		nick = strdup(word[index[0]]);
		if (nick == NULL) {
			free(message);
			log_printf(0, "AFR: ERROR: Out of memory.");
			return XCHAT_EAT_NONE;
		}
	}

	if (index[1] > 0) {
		free(message);
		message = strdup(word[index[1]]);
		if (message == NULL) {
			free(nick);
			log_printf(0, "AFR: ERROR: Out of memory.");
			return XCHAT_EAT_NONE;
		}
	}

	brain(nick, message, index[2]);

	free(nick);
	free(message);

	return XCHAT_EAT_NONE;

}

/*
 * pump_cb sits and waits for xchat to signal to pump the plugin and does so
 */

int pump_cb(void *userdata) {
	int *index = (int *) userdata;
	char none[1] = "";

	brain(none, none, index[2]);

	return 1; /* return 1 to keep the timeout going */
}

/*
 * server_text_cb sits and waits for Server Text related Text Events and handles them
 */

int server_text_cb(char *word[], void *userdata) {
	char *nick = strdup(word[1]);
	char *message = NULL;
	if (nick == NULL) {
		log_printf(0, "AFR: ERROR: Out of memory.");
		return XCHAT_EAT_NONE;
	}
	if ((message = strchr(nick, ':')) != NULL) {
		message--;
		*message++ = '\0';
		*message++ = '\0';
		brain(nick, message, 2);
	}

	free(nick);

	return XCHAT_EAT_NONE;
}
