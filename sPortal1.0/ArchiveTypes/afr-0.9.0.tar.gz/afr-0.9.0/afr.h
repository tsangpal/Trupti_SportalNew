/*
 * Automated File Retrieval
 * Copyright (C) 2003 Bailey Kong
 *
 * This file is part of Automated File Retrieval (AFR).
 *
 * AFR is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * AFR is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with AFR; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _AFR_H
#define _AFR_H

#define PLUGIN_NAME "AFR"
#define PLUGIN_DESC "Automated File Retrival"
#define PLUGIN_VERS "0.9.0"

#define NICK_MAX 30
#define CHAN_MAX 32
#define ERROR_MAX 256
#define GOT_MAX_REQUESTS 2

#define OFFERED_CHAT 1
#define ESTABLISHED_CHAT 2
#define REQUESTED_FILE 4
#define COMPLETED 8

#define MAX_TARGETS 10

#ifndef NAME_MAX
#define NAME_MAX 255
#endif

#define dequeue(target) remove_query(target, target->head)

#include <stdlib.h>
#include <time.h>
#include "xchat-plugin.h"

extern xchat_plugin *ph;   /* plugin handle */
extern int target_count;
extern int debug_level;
extern int use_checksum;

struct query {
	char *command; /* IRC Command in which to contact the IRC File Server */
	char *directory; /* Path to filename on the server */
	char *file_id; /* Filename or list number (including #) */
	char *filename_requested; /* real filename limited to size NAME_MAX */
	char *dest_filename; /* path + new filename (new filename could be filename with .1 or .2 after it */
	unsigned char status; /* status of file request */
	time_t completed_ts; /* timestamp of when the query was completed */
	char *crc32;
	char *md5;
	struct query *next; /* Pointer to the next filename */
};

struct target {
	char *nick; /* IRC NIckname */
	char *channel; /* IRC Channel the Nickname resides in */
	unsigned char is_dcc; /* Type of File Server: 1 = DCC (XDCC, TDCC) Server; 0 = Regular Server */
	unsigned char max_requests;
	/* should we change error to a char ptr, declare error_timeout first (mem optimization)  */
	char error[ERROR_MAX]; /* Error Message if unable to continue to access server */
	char error_timeout; /* Time before releasing the error message and trying again (1 = 5mins, 2 = 10mins, etc). Must wait another 5 mins after releasing error */
	xchat_context *current_context;
	struct query *head; /* Pointer to the beginning of the queue */
	struct query *tail; /* Pointer to the end of the queue */
	struct target *next; /* Pointer to the next person on the list */
};

struct to_thread {
	struct target *target;
	struct query *item;
};

extern struct target *current;  /* Pointer to the list */
extern struct target *first;  /* Pointer to the beginning of the list */

struct query *create_query(const char *u_command, const char *u_directory, const char *u_fileid);
struct target *create_target(const char *u_nick, xchat_context *u_context);
struct to_thread *create_to_thread(struct target *u_target, struct query *u_item);
void destroy_query(struct query *item);
void destroy_target(struct target *target);
void enqueue(struct target *target, struct query *item);
struct query *remove_query(struct target *target, struct query *item);
struct target *remove_target(struct target *target);


#endif
