/*
 * Automated File Retrieval
 * Copyright (C) 2003 Bailey Kong
 *
 * This file is part of Automated File Retrieval (AFR).
 *
 * AFR is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * AFR is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with AFR; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <ctype.h>
#include <stdio.h>
#define __USE_GNU
#include <string.h>
#include "afr.h"
#include "brain.h"
#include "checksum.h"
#include "event_handlers.h"
#include "manage_list_lock.h"
#include "utils.h"

struct query *locate_query(const struct target *target, const int item_num) {
	struct query *temp_item = NULL;
	if (target != NULL && item_num > 0) {
		int counter = 1;
		temp_item = target->head;
		/* find the query item we're looking for */
		while (temp_item != NULL && counter < item_num) {
			temp_item = temp_item->next;
			counter++;
		}
	}
	return temp_item;
}

struct target *locate_target(const int target_num) {
	struct target *temp_list = NULL;
	if (target_num > 0) {
		int counter = 1;
		temp_list = first;
		/* find the target we're looking for */
		while (temp_list != NULL && counter < target_num) {
			temp_list = temp_list->next;
			counter++;
		}
	}
	return temp_list;
}

/*
 * crc32_cb
 */

int crc32_cb(char *word[], char *word_eol[], void *userdata) {
	char *request_id = strdup(word[2]);
	if (request_id == NULL) {
		log_printf(0, "AFR: ERROR: Out of memory.");
		return XCHAT_EAT_ALL;
	}

	char *str_item_num;
	if ((str_item_num = strchr(request_id, '.')) != NULL) {
		if (is_crc32(word[3])) {
			*str_item_num++ = '\0';
			int target_num = toupper(*request_id)-64;
			int item_num = atoi(str_item_num);;

			if (!manage_list_lock(LOCK_LIST))
				return XCHAT_EAT_ALL;

			struct query *temp = NULL;
			if ((temp = locate_query(locate_target(target_num), item_num)) != NULL) {
				temp->crc32 = strndup(word[3], 8);
			} else {
				log_printf(1, "debug1: Could not find requestid %s.", word[2]);
				xchat_printf(ph, "AFR: Could not find requestid %s.", word[2]);
			}

			manage_list_lock(UNLOCK_LIST);
		} else {
			log_printf(1, "debug1: %s is an invalid crc32 checksum.", word[3]);
			xchat_printf(ph, "AFR: %s is an invalid crc32 checksum.", word[3]);
		}
	} else {
		log_printf(1, "debug1: Invalid argument please use /help %s for more info!", word[1]);
		xchat_printf(ph, "AFR: Invalid argument please use /help %s for more info!", word[1]);
	}
	free(request_id);

	return XCHAT_EAT_ALL;
}

/*
 * debug_cb turns on/off the plugin's debugging 
 */

int debug_cb(char *word[], char *word_eol[], void *userdata) {

	if (atoi(word[2]) < 1) {
		debug_level = -1;
		xchat_printf(ph, "AFR: Debugging for %s turned OFF", PLUGIN_NAME);
	} else if (atoi(word[2]) > 2) {
		debug_level = 3;
		xchat_printf(ph, "AFR: Debugging for %s set to level 3", PLUGIN_NAME);
	} else {
		debug_level = atoi(word[2]);
		xchat_printf(ph, "AFR: Debugging for %s set to level %d", PLUGIN_NAME, debug_level);
	}

	return XCHAT_EAT_ALL;  /* eat this command so xchat and other plugins can't process it */
}

/*
 * enqueue_cb adds requests to the queue
 */

int enqueue_cb(char *word[], char *word_eol[], void *userdata) {
	if (!manage_list_lock(LOCK_LIST))
		return XCHAT_EAT_ALL;

	if (current != NULL) {
		current->channel = strndup(word[4], CHAN_MAX);

		if (strlen(word[2]) && strlen(word[3])) {
			if (strcasestr(word[3], "dcc") != NULL && strstr(word[2], "#") != NULL)
				current->is_dcc = 1;

			char *dir = NULL;
			char *file_id = NULL;
			/* Only use directory if its not a XDCC Server */
			if (!current->is_dcc) {
				dir = strdup(word[2]);
				if (dir == NULL) {
					log_printf(0, "AFR: ERROR: Out of memory.");
					manage_list_lock(UNLOCK_LIST);
					return XCHAT_EAT_ALL;
				}

				/* set pointer new->filename to the last occurance of '/' in new->directory
				   then change what new->filename is to '\0', and increment it */
				if ((file_id = strrchr(dir, '/')) != NULL) {
					*file_id++ = '\0';
				} else {
					dir = (char *) realloc(dir, sizeof(char));
					if (dir == NULL) {
						log_printf(0, "AFR: ERROR: Out of memory.");
						manage_list_lock(UNLOCK_LIST);
						return XCHAT_EAT_ALL;
					}
					*dir = '\0';

					file_id = strdup(word[2]);
					if (file_id == NULL) {
						log_printf(0, "AFR: ERROR: Out of memory.");
						manage_list_lock(UNLOCK_LIST);
						free(dir);
						return XCHAT_EAT_ALL;
					}
				}
			} else {
				dir = malloc(sizeof(char));
				if (dir == NULL) {
					log_printf(0, "AFR: ERROR: Out of memory.");
					manage_list_lock(UNLOCK_LIST);
					return XCHAT_EAT_ALL;
				}
				*dir = '\0';

				file_id = strdup(word[2]);
				if (file_id == NULL) {
					log_printf(0, "AFR: ERROR: Out of memory.");
					manage_list_lock(UNLOCK_LIST);
					free(dir);
					return XCHAT_EAT_ALL;
				}
			}
			struct query *new = create_query(word[3], dir, file_id);
			free(file_id);
			free(dir);
			if (new == NULL) {
				manage_list_lock(UNLOCK_LIST);
				return XCHAT_EAT_ALL;
			}
			enqueue(current, new);
			log_printf(1, "debug1: %s has been queued for %s.", new->file_id, current->nick);
			xchat_printf(ph, "AFR: %s has been queued for %s.", new->file_id, current->nick);

		} else
			xchat_printf(ph, "AFR: Invalid use of %s, please use /help %s for usage information. ",
				     word[1], word[1]);

	} else {
		log_printf(1, "debug1: No targets have been set yet, cannot access queue");
		xchat_print(ph, "AFR: You have not set any targets yet.");
	}

	manage_list_lock(UNLOCK_LIST);
	return XCHAT_EAT_ALL;   /* eat this command so xchat and other plugins can't process it */
}

/*
 * help_cb displays the list of commands and their descriptions
 */

int help_cb() {

	xchat_print(ph, "****************************** Automated File Retrieval ******************************");
	xchat_print(ph, "*                                                                                     ");
	xchat_print(ph, "*  afr-crc32 <requestid> <crc32> -                                                    ");
	xchat_print(ph, "*                                  Set the crc32 checksum for a request.              ");
	xchat_print(ph, "*                                  (eg. afr-crc32 A.1 D0CB05C4 to set the first file  ");
	xchat_print(ph, "*                                  of the first target.)                              ");
	xchat_print(ph, "*  afr-debug <0|1|2|3>          -  Setting debug info level.                          ");
	xchat_print(ph, "*  afr-enqueue \"<filename>\" \"<command>\" <channel> -                               ");
	xchat_print(ph, "*                                  Queuing file for current target. (channel is       ");
	xchat_print(ph, "*                                  only needed if command to access the fserve needs  ");
	xchat_print(ph, "*                                  to be sent to the channel.)                        ");
	xchat_print(ph, "*  afr-help                     -  Display this help info.                            ");
	xchat_print(ph, "*  afr-list                     -  Display current list of Targets/Queues.            ");
	xchat_print(ph, "*  afr-load <filename>          -  Location of file created by afr-save.              ");
	xchat_print(ph, "*  afr-md5 <requestid> <md5>    -  Set the md5 checksum for a request.                ");
	xchat_print(ph, "*                                  (eg. afr-md5 A.1 66820a4825174eceb471f479cd98f827  ");
	xchat_print(ph, "*                                  to set the first file of the first target.)        ");
	xchat_print(ph, "*  afr-next                     -  Forcing the request of current Target to be        ");
	xchat_print(ph, "*                                  executed.                                          ");
	xchat_print(ph, "*  afr-remove <requestid>       -  Removing Target/Queue (eg. afr-remove A.1 to       ");
	xchat_print(ph, "*                                  remove the first file of the first target.         ");
	xchat_print(ph, "*  afr-save <filename>          -  Location where to create the file.                 ");
	xchat_print(ph, "*  afr-target <nick>            -  Nickname of the person you which to retrieve       ");
	xchat_print(ph, "*                                  files from.                                        ");
	xchat_print(ph, "*  afr-toggle <on|off>          -  Turning on/off the plugin's automation.            ");
	xchat_print(ph, "*  afr-toggle-checksum <on|off> -  Turning on/off the plugin's checksum feature.      ");
	xchat_print(ph, "*                                                                                     ");
	xchat_print(ph, "**************************************************************************************");

	return XCHAT_EAT_ALL;
}

/*
 * list_cb displays the list of targets and their queues 
 */

int list_cb() {
	if (!manage_list_lock(LOCK_LIST))
		return XCHAT_EAT_ALL;

	if (first != NULL) { 
		char target_counter = 'A';
		int item_counter;
		struct target *temp_list = first;
		struct query *temp_queue = NULL;
		while (temp_list != NULL) {
			item_counter = 1;
			xchat_printf(ph, "AFR: %c. Requests queued for %s",
				     target_counter, temp_list->nick);

			if (debug_level == 3) {
				xchat_printf(ph, "AFR:     error_timeout: %d", temp_list->error_timeout);
			}

			if (strlen(temp_list->error))
				xchat_printf(ph, "AFR:     Error: %s", temp_list->error);
			if (temp_list->channel != NULL)
				xchat_printf(ph, "AFR:     Channel: %s", temp_list->channel);

			temp_queue = temp_list->head;
			while (temp_queue != NULL) {
				xchat_printf(ph, "AFR:       %d. Command: %s %s",
					     item_counter, 
					     temp_queue->command,
					     (temp_queue->status & REQUESTED_FILE) ? "(requested)" : "");
				if (strlen(temp_queue->directory))
					xchat_printf(ph, "AFR:        Directory: %s",
						     temp_queue->directory);
				xchat_printf(ph, "AFR:         Filename: %s", temp_queue->file_id);
				xchat_printf(ph, "AFR:            crc32: %s", temp_queue->crc32);
				xchat_printf(ph, "AFR:              md5: %s", temp_queue->md5);
				if (debug_level == 3) {
					xchat_printf(ph, "AFR:          offered_chat: %d",
						     !!(temp_queue->status & OFFERED_CHAT));
					xchat_printf(ph, "AFR:          established_chat: %d",
						     !!(temp_queue->status & ESTABLISHED_CHAT));
					xchat_printf(ph, "AFR:          requested_file: %d",
						     !!(temp_queue->status & REQUESTED_FILE));
				}

				temp_queue = temp_queue->next;
				item_counter++;
			}
			temp_list = temp_list->next;
			target_counter++;
		}
	} else
		xchat_print(ph, "AFR: You have not set any targets yet.");

	manage_list_lock(UNLOCK_LIST);
	return XCHAT_EAT_ALL;   /* eat this command so xchat and other plugins can't process it */
}

/*
 * load_cb loads a file created by save_cb
 */

int load_cb(char *word[], char *word_eol[], void *userdata) {
	char *filename = (strlen(word_eol[2])) ? word_eol[2] : "afr.save";
	if (filename == NULL) {
		log_printf(0, "AFR: ERROR: Out of memory.");
		return XCHAT_EAT_ALL;
	}

	FILE *file_ptr = wc_fopen(filename, "r");
	if (file_ptr != NULL) {
		fclose(file_ptr);
		log_printf(1, "debug1: Loading from %s", filename);
		xchat_printf(ph, "AFR: Loading from %s", filename);
		xchat_commandf(ph, "load -e %s", filename);
	} else {
		log_printf(1, "debug1: Load: %s does not exist.", filename);
		xchat_printf(ph, "AFR: Load: %s does not exist.", filename);
	}

	return XCHAT_EAT_ALL;
}

/*
 * md5_cb
 */

int md5_cb(char *word[], char *word_eol[], void *userdata) {
	char *request_id = strdup(word[2]);
	if (request_id == NULL) {
		log_printf(0, "AFR: ERROR: Out of memory.");
		return XCHAT_EAT_ALL;
	}

	char *str_item_num;
	if ((str_item_num = strchr(request_id, '.')) != NULL) {
		if (is_md5(word[3])) {
			*str_item_num++ = '\0';
			int target_num = toupper(*request_id)-64;
			int item_num = atoi(str_item_num);;

			if (!manage_list_lock(LOCK_LIST))
				return XCHAT_EAT_ALL;

			struct query *temp = NULL;
			if ((temp = locate_query(locate_target(target_num), item_num)) != NULL) {
				temp->md5 = strndup(word[3], 32);
			} else {
				log_printf(1, "debug1: Could not find requestid %s.", word[2]);
				xchat_printf(ph, "AFR: Could not find requestid %s.", word[2]);
			}

			manage_list_lock(UNLOCK_LIST);
		} else {
			log_printf(1, "debug1: %s is an invalid md5 checksum.", word[3]);
			xchat_printf(ph, "AFR: %s is an invalid md5 checksum.", word[3]);
		}
	} else {
		log_printf(1, "debug1: Invalid argument please use /help %s for more info!", word[1]);
		xchat_printf(ph, "AFR: Invalid argument please use /help %s for more info!", word[1]);
	}
	free(request_id);

	return XCHAT_EAT_ALL;
}

/*
 * next_cb jumpstarts the request of the current target
 */

int next_cb(char *word[], char *word_eol[], void *userdata) {
	/* brain also locks the list, so we have to unlock before using it
	   to prevent double locking, thats why we have unlocks all over
	   the place */
	if (!manage_list_lock(LOCK_LIST))
		return XCHAT_EAT_ALL;

	if (current != NULL) {
		if (current->head != NULL) {
			char none[1] = {'\0'};
			/* make a copy of nick because we don't know if the list will change
			   between unlocking the list and brain locking the list */
			char *nick = strdup(current->nick);
			manage_list_lock(UNLOCK_LIST);

			brain(nick, none, 9);
			free(nick);
		} else {
			manage_list_lock(UNLOCK_LIST);
			log_printf(1, "debug1: No files in the queue, cannot force non-existant requests.");
			xchat_print(ph, "AFR: You have not set any file(s) to be requested from current target.");
		}
	} else {
		manage_list_lock(UNLOCK_LIST);
		log_printf(1, "debug1: No targets have been set yet, cannot force requests to non-existant targets.");
		xchat_print(ph, "AFR: You have not set any targets yet.");
	}

	return XCHAT_EAT_ALL;
}

/*
 * remove_cb deletes targets/requests from the list/queue
 */

int remove_cb(char *word[], char *word_eol[], void *userdata) {
	char *remove_id = strdup(word[2]);
	if (remove_id == NULL) {
		log_printf(0, "AFR: ERROR: Out of memory.");
		return XCHAT_EAT_ALL;
	}

	int target_num = toupper(*remove_id)-64;
	if (!manage_list_lock(LOCK_LIST))
		return XCHAT_EAT_ALL;

	if (first == NULL) {
		log_printf(1, "debug1: No targets have been set yet, nothing to be removed.");
		xchat_print(ph, "AFR: You have not set any targets yet.");
	} else {
		struct target *removed_target = locate_target(target_num);
		if (removed_target == NULL) {
			log_printf(1, "debug1: Unable to locate %s, nothing removed. (target_num: %d)",
				   word[2],
				   target_num);
			xchat_printf(ph, "AFR: Unable to locate %s, nothing removed.", word[2]);
		} else {
			char *str_item_num = strchr(remove_id, '.');
			/* no item number specified meaning we're going to remove the whole target */
			if (str_item_num == NULL) {
				log_printf(1, "debug1: %s: %s has been removed.",
					   word[2],
					   removed_target->nick);
				xchat_printf(ph, "AFR: %s: %s has been removed.",
					     word[2],
					     removed_target->nick);
				destroy_target(remove_target(removed_target));
			/* item number was specified, so we're removing an item not a whole target */
			} else {
				*str_item_num++ = '\0';
				int item_num = atoi(str_item_num);

				struct query *removed_item = locate_query(removed_target, item_num);
				if (removed_item == NULL) {
					log_printf(1, "debug1: Unable to locate %s, nothing removed. (target_num: %d, item_num: %d)",
						   word[2],
						   target_num,
						   item_num);
					xchat_printf(ph, "AFR: Unable to locate %s, nothing removed.", word[2]);
				} else {
					log_printf(1, "debug1: %s: %s has been removed. (target_num: %d, item_num: %d)",
						   word[2],
						   removed_item->file_id,
						   target_num,
						   item_num);
					xchat_printf(ph, "AFR: %s: %s has been removed.", word[2], removed_item->file_id);
					destroy_query(remove_query(removed_target, removed_item));
				}
			}
		}
	}

	manage_list_lock(UNLOCK_LIST);
	free(remove_id);

	return XCHAT_EAT_ALL;  /* eat this command so xchat and other plugins can't process it */
}

/*
 * save_cb saves the commands needed to recreate the data structure
 */

int save_cb(char *word[], char *word_eol[], void *userdata) {
	char *filename = (strlen(word_eol[2])) ? strdup(word_eol[2]) : strdup("afr.save");
	if (filename == NULL) {
		log_printf(0, "AFR: ERROR: Out of memory.");
		return XCHAT_EAT_ALL;
	}

	FILE *file_ptr = wc_fopen(filename, "w");
	if (file_ptr != NULL) {
		log_printf(1, "debug1: Saving to %s", filename);
		xchat_printf(ph, "AFR: Saving to %s", filename);
		fprintf(file_ptr, "afr-debug %i\n", debug_level);
		fprintf(file_ptr, "afr-toggle-checksum %i\n", use_checksum);

		if (!manage_list_lock(LOCK_LIST))
			return XCHAT_EAT_ALL;

		struct target *temp_target = first;
		while (temp_target != NULL) {
			fprintf(file_ptr, "afr-target %s\n", temp_target->nick);
			struct query *temp_queue = temp_target->head;
			while (temp_queue != NULL) {
				if (temp_target->is_dcc) {
					fprintf(file_ptr, "afr-enqueue \"%s\" \"%s\"\n",
						temp_queue->file_id,
						temp_queue->command);
				} else {
					fprintf(file_ptr, "afr-enqueue \"%s/%s\" \"%s\" \"%s\"\n",
						temp_queue->directory,
						temp_queue->file_id,
						temp_queue->command,
						(temp_target->channel == NULL) ? "" : temp_target->channel);
				}
				if (temp_queue->next == NULL)
					break;
				temp_queue = temp_queue->next;
			}
			temp_target = temp_target->next;
		}
		manage_list_lock(UNLOCK_LIST);
		fclose(file_ptr);
	} else {
		log_printf(1, "debug1: Save: %s can not be opened for writing.", filename);
		xchat_printf(ph, "AFR: Save: %s can not be opened for writing.", filename);
	}
	free(filename);

	return XCHAT_EAT_ALL;
}

/*
 * target_cb adds IRC Nicknames to the list
 */

int target_cb(char *word[], char *word_eol[], void *userdata) {
	if (strlen(word[2]) == 0) {
		log_printf(1, "debug1: Invalid argument please use /help %s for more info!", word[1]);
		xchat_printf(ph, "AFR: Invalid argument please use /help %s for more info!", word[1]);
	}

	if (!manage_list_lock(LOCK_LIST))
		return XCHAT_EAT_ALL;

	current = first;
	/* Traverse the list of targets to find if target is already there */
	while (current != NULL) {
		if (strcasecmp(current->nick, word[2]) == 0) {
			log_printf(1, "debug1: Targeting already existing target, %s", current->nick);
			xchat_printf(ph, "AFR: %s has been targeted.", current->nick);
			manage_list_lock(UNLOCK_LIST);
			return XCHAT_EAT_ALL;
		}
		/* we're at the end of the list and we didn't find the target */
		if (current->next == NULL)
			break;
		current = current->next;
	}
	/* Target was not found on the list */
	/* Check to see if there are 10 targets yet (max allowed = 10) */
	if (target_count < MAX_TARGETS) {
		struct target *new = create_target(word[2], xchat_get_context(ph));
		if (new == NULL) {
			manage_list_lock(UNLOCK_LIST);
			return XCHAT_EAT_ALL;
		}
		/* if this is the first target, we can't add the new 
		 * target to next, so we need to actually start the list */
		if (first == NULL) {
			first = current = new;
		} else {
			current->next = new;
			current = current->next;
		}
		target_count++;
		log_printf(1, "debug1: Targeting newly created target, %s", current->nick);
		xchat_printf(ph, "AFR: %s has been targeted.", current->nick);
	} else {
		log_printf(1, "debug1: Too many targets on the list, some need to be aborted first");
		xchat_print(ph, "AFR: You have too many targets on the list, please abort some first.");
	}

	manage_list_lock(UNLOCK_LIST);
	return XCHAT_EAT_ALL;   /* eat this command so xchat and other plugins can't process it */
}

/*
 * toggle_checksum_cb turns on/off the plugin's file verification 
 */

int toggle_checksum_cb(char *word[], char *word_eol[], void *userdata) {

	if (strcasecmp(word[2], "on") == 0 || strcasecmp(word[2], "1") == 0) {
		if (use_checksum == 0) {
			use_checksum = 1;
			xchat_printf(ph, "AFR: File verification for %s turned ON", PLUGIN_NAME);
		} else
			xchat_printf(ph, "AFR: File verification for %s already ON", PLUGIN_NAME);
	} else if (strcasecmp(word[2], "off") == 0 || strcasecmp(word[2], "0") == 0) {
		if (use_checksum == 1) {
			use_checksum = 0;
			xchat_printf(ph, "AFR: File verification for %s turned OFF", PLUGIN_NAME);
		} else
			xchat_printf(ph, "AFR: File verification for %s already OFF", PLUGIN_NAME);
	} else {
		log_printf(1, "debug1: Invalid argument please use /help %s for more info!", word[1]);
		xchat_printf(ph, "AFR: Invalid argument please use /help %s for more info!", word[1]);
	}

	return XCHAT_EAT_ALL;  /* eat this command so xchat and other plugins can't process it */
}

/*
 * toggle_plugin_cb turns on/off the plugin's automation 
 */

int toggle_plugin_cb(char *word[], char *word_eol[], void *userdata) {
	static int enable = 0; /* Plugin is not turned on by default */
	char none[1] = {'\0'};
	/* usage of different 'Text Events'
	 * first column = nick
	 * second column = message
	 * third column = source (text event)
	 */
	static int pm[3] = {1, 2, 1};
	static int ct[3] = {3, 4, 1};
	static int co[3] = {1, 0, 3};
	static int cc[3] = {1, 0, 4};
	static int so[3] = {1, 2, 5};
	static int rf[3] = {3, 1, 6};
	static int ds[3] = {3, 1, 6};
	static int rc[3] = {3, 2, 7};
	static int all[3] = {0, 0, 8};
	static xchat_hook *priv_msg = NULL;
	static xchat_hook *pm_diag = NULL;
	static xchat_hook *notices = NULL;
	static xchat_hook *chat_text = NULL;
	static xchat_hook *chat_offer = NULL;
	static xchat_hook *chat_conn = NULL;
	static xchat_hook *send_offer = NULL;
	static xchat_hook *recv_failed = NULL;
	static xchat_hook *dcc_stall = NULL;
	static xchat_hook *recv_comp = NULL;
	static xchat_hook *serv_text = NULL;
	static xchat_hook *timer = NULL;

	if (strcasecmp(word[2], "on") == 0 || strcasecmp(word[2], "1") == 0) {
		if (enable != 1) {
			priv_msg = xchat_hook_print(ph, "Private Message", XCHAT_PRI_NORM, eyes_cb, pm); 
			pm_diag = xchat_hook_print(ph, "Private Message to Dialog", XCHAT_PRI_NORM, eyes_cb, pm); 
			notices = xchat_hook_print(ph, "Notice", XCHAT_PRI_NORM, eyes_cb, pm);
			chat_text = xchat_hook_print(ph, "DCC CHAT Text", XCHAT_PRI_NORM, eyes_cb, ct); 
			chat_offer = xchat_hook_print(ph, "DCC CHAT Offer", XCHAT_PRI_NORM, eyes_cb, co); 
			chat_conn = xchat_hook_print(ph, "DCC CHAT Connect", XCHAT_PRI_NORM, eyes_cb, cc); 
			send_offer = xchat_hook_print(ph, "DCC SEND Offer", XCHAT_PRI_NORM, eyes_cb, so); 
			recv_failed = xchat_hook_print(ph, "DCC RECV Failed", XCHAT_PRI_NORM, eyes_cb, rf); 
			dcc_stall = xchat_hook_print(ph, "DCC Stall", XCHAT_PRI_NORM, eyes_cb, ds); 
			recv_comp = xchat_hook_print(ph, "DCC RECV Complete", XCHAT_PRI_NORM, eyes_cb, rc); 
			serv_text = xchat_hook_print(ph, "Server Text", XCHAT_PRI_NORM, server_text_cb, NULL); 
			timer = xchat_hook_timer(ph, 300000, pump_cb, all);
			enable = 1;
			xchat_printf(ph, "AFR: %s turned ON", PLUGIN_NAME);
			brain(none, none, all[2]);
		} else
			xchat_printf(ph, "AFR: %s already ON", PLUGIN_NAME);
	} else if (strcasecmp(word[2], "off") == 0 || strcasecmp(word[2], "0") == 0) {
		if (enable != 0) {
			xchat_unhook(ph, priv_msg);
			xchat_unhook(ph, pm_diag);
			xchat_unhook(ph, notices);
			xchat_unhook(ph, chat_text);
			xchat_unhook(ph, chat_offer);
			xchat_unhook(ph, chat_conn);
			xchat_unhook(ph, send_offer);
			xchat_unhook(ph, recv_failed);
			xchat_unhook(ph, dcc_stall);
			xchat_unhook(ph, recv_comp);
			xchat_unhook(ph, serv_text);
			xchat_unhook(ph, timer);
			enable = 0;
			xchat_printf(ph, "AFR: %s turned OFF", PLUGIN_NAME);
		} else
			xchat_printf(ph, "AFR: %s already OFF", PLUGIN_NAME);
	} else {
		log_printf(1, "debug1: Invalid argument please use /help %s for more info!", word[1]);
		xchat_printf(ph, "AFR: Invalid argument please use /help %s for more info!", word[1]);
	}

	return XCHAT_EAT_ALL;  /* eat this command so xchat and other plugins can't process it */
}
