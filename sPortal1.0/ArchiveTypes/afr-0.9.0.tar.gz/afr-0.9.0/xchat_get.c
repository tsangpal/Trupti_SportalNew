/*
 * Automated File Retrieval
 * Copyright (C) 2003 Bailey Kong
 *
 * This file is part of Automated File Retrieval (AFR).
 *
 * AFR is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * AFR is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with AFR; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <string.h>
#include "afr.h"

xchat_context *get_channel_context(const char *channel) {
	void *chan_list = xchat_list_get(ph, "channels");
	while(xchat_list_next(ph, chan_list)) {
		if (strcasecmp(xchat_list_str(ph, chan_list, "channel"), channel) == 0)
			return (xchat_context *)xchat_list_str(ph, chan_list, "context");
	}
	xchat_list_free(ph, chan_list);
	return NULL;
}

int get_prefs(const char *pref) {
	int integer;
	const char *string = NULL;

	xchat_get_prefs(ph, pref, &string, &integer);

	return integer;
}
