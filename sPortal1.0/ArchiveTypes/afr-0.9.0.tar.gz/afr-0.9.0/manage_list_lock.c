/*
 * Automated File Retrieval
 * Copyright (C) 2003 Bailey Kong
 *
 * This file is part of Automated File Retrieval (AFR).
 *
 * AFR is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * AFR is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with AFR; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <pthread.h>
#include "afr.h"
#include "manage_list_lock.h"
#include "utils.h"

int manage_list_lock(const int status) {
	static pthread_mutex_t list_mutex = PTHREAD_MUTEX_INITIALIZER;
	if (status == LOCK_LIST) {
		if (pthread_mutex_lock(&list_mutex)) {
			log_printf(0, "AFR: ERROR: pthread_mutex_lock failed");
			return 0;
		}
	} else if (status == UNLOCK_LIST) {
		if (pthread_mutex_unlock(&list_mutex)) {
			log_printf(0, "AFR: ERROR: pthread_mutex_unlock failed");
			return 0;
		}
	}
	return 1;
}
