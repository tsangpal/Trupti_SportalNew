/*
 * Automated File Retrieval
 * Copyright (C) 2003 Bailey Kong
 *
 * This file is part of Automated File Retrieval (AFR).
 *
 * AFR is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * AFR is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with AFR; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <pthread.h>
#include <stdio.h>
#define __USE_GNU
#include <string.h>
#include <time.h>
#include "afr.h"
#include "brain.h"
#include "checksum.h"
#include "dcc.h"
#include "manage_list_lock.h"
#include "utils.h"

/*
 * brain 
 */

int brain(const char *nick, const char *message, const int source) {
	int counter = 0;
	char *sends_str = NULL;
	char *queues_str = NULL;
	char *temp_str = NULL;
	struct query *temp_item = NULL;

	if (!manage_list_lock(LOCK_LIST))
		return 0;

	struct target *current_ptr = current;
	/* source == 9 is afr-next we should already be set on the right target */
	if (source != 9) {
		current = first;
	}
	while (current != NULL) {
		if ((current->head != NULL || source >= 10) && 
		    (source == 8 || source == 13 || strcasecmp(current->nick, nick) == 0)) {
			/*
			 * 1: "Private Message"
			 *    "Private Message to Dialog"
			 *    "DCC CHAT Text"
			 * 2: "Server Text"
			 * 3: "DCC CHAT Offer"
			 * 4: "DCC CHAT Connect"
			 * 5: "DCC SEND Offer"
			 * 6: "DCC RECV Failed"
			 *    "DCC Stall"
			 * 7-9: "DCC RECV Complete"
			 * 8: Toggle On
			 * 9: afr-next command pushes the next file to be requested
			 * 10: "Change Nick"
			 * 11: "Join"
			 * 12: "Quit"
			 * 13: Prune Completed Items
			 */
			 /* error_timeout should always be set to 1 less than the desired time, 
			    because it takes another 5 mins to go after the error_timeout is set back to 0. 
			    so error_timeout = 2 is actually 15mins before the file is requested again.  */
			switch (source) {
				case 1:
					if (((strcasestr(message, "queue") || strcasestr(message, "slots")) &&
					     strcasestr(message, "full") && !strcasestr(message, "add")) || 
					    (strcasestr(message, "only have") && strcasestr(message, "transfer at a time")) || /* FIXME: should queued be considered requested? */
					    strcasestr(message, "try again later") || 
					    strcasestr(message, "connection reset by peer") != NULL) {
						strcpy(current->error, "Will retry.");
						reset_checks(2);
					} else if (strcasestr(message, "restrict") && strcasestr(message, "trigger")) {
						strncpy(current->error, message, ERROR_MAX-1);
						reset_checks(-1);
					/* TODO: this is actually no longer the case sometimes, therefore we should detect if
					 * dccserver is installed on the client and use it
					 */
					} else if (strcasestr(message, "/dccserver") != NULL) {
						strcpy(current->error, "Server requires /dccserver. That's only in mIRC.");
						reset_checks(-1);
					/* is this the same as case 6? */
					} else if (strcasestr(message, "dcc timeout") != NULL) {
						strcpy(current->error, "Transfer timed out or stalled.");
						temp_item = current->head;
						while (temp_item != NULL) {
							if (strstr(message, temp_item->filename_requested) != NULL) {
								free(temp_item->filename_requested);
								temp_item->filename_requested = NULL;
								reset_checks(0);
								break;
							}
							temp_item = temp_item->next;
						}
					} else if (use_checksum && strcasestr(message, "completed") != NULL) {
						temp_item = current->head;
						while (temp_item != NULL &&
						       (temp_item->filename_requested == NULL ||
						        (temp_item->filename_requested != NULL &&
							strstr(message, temp_item->filename_requested) == NULL)))
							temp_item = temp_item->next;
						if (temp_item != NULL) {
							char *u_checksum = NULL;
							if ((u_checksum = strcasestr(message, "crc:")) != NULL) {
								temp_item->crc32 = get_crc32(u_checksum);
							}
							if ((u_checksum = strcasestr(message, "md5:")) != NULL) {
								temp_item->md5 = get_md5(u_checksum);
							}
							/* make sure we didn't accidentally pick up part of the md5 checksum
							   and said it was a crc32 checksum. */
							if (temp_item->md5 != NULL &&
							    temp_item->crc32 != NULL &&
							    strcasestr(temp_item->md5, temp_item->crc32) != NULL) {
								free(temp_item->crc32);
								temp_item->crc32 = NULL;
							}
							pthread_t p_thread;
							pthread_create(&p_thread,
								       NULL,
								       checksum,
								       (void *)create_to_thread(current, remove_query(current, temp_item)));
						}
					/* FIXME: not sure how useful this is, needs to be investigated */
					} else if ((sends_str = strcasestr(message, "your sends")) != NULL &&
						   (queues_str = strcasestr(message, "your queues")) != NULL) {
						while (*sends_str < '0' && *sends_str > '9')
							sends_str++;
						while (*queues_str < '0' && *queues_str > '9')
							queues_str++;
						sends_str++;
						queues_str++;
						if (*sends_str++ == '/' && *queues_str++ == '/') {
							current->max_requests = (*sends_str-48)+(*queues_str-48);
							current->is_dcc |= GOT_MAX_REQUESTS;
						}
					}
					break;
				case 2:
					if (strcasestr(message, "no such nick/channel") != NULL) {
						strcpy(current->error, "Server could not find nick.");
						reset_checks(-2);
					}
					break;
				case 3:
					temp_item = current->head;
					while (temp_item != NULL) {
						if (temp_item->status & OFFERED_CHAT) {
							establish_dccchat(temp_item);
							break;
						}
						temp_item = temp_item->next;
					}
					break;
				case 4:
					counter = 0;
					temp_item = current->head;
					while (temp_item != NULL && counter < current->max_requests) {
						if (temp_item->status ^ COMPLETED) {
							if (temp_item->status ^ REQUESTED_FILE) {
								/* request_file returns 0 if the requesting the file wasn't successful */
								temp_item->status |= request_file(temp_item);
							}
							if (temp_item->status & REQUESTED_FILE)
								counter++;
						}
						temp_item = temp_item->next;
					}
					break;
				case 5:
					temp_item = current->head;
					while (temp_item != NULL) {
						if (temp_item->status & REQUESTED_FILE) {
							log_printf(2, "debug2: brain: %s =? %s", current->head->file_id, message);
							if (current->is_dcc || (strcmp(current->head->file_id, message) == 0)) {
								establish_dccrecv(temp_item, message);
							} else {
								char *space_ptr;
								char *new_filename = strdup(current->head->file_id);
								if (new_filename == NULL) {
									log_printf(0, "AFR: ERROR: Out of memory.");
								} else {
									while ((space_ptr = strchr(new_filename, ' ')) != NULL)
										*space_ptr = '_';
									if (strcmp(new_filename, message) == 0)
										establish_dccrecv(temp_item, message);
									free(new_filename);
								}
							}
							break;
						}
						temp_item = temp_item->next;
					}
					break;
				case 6:
					strcpy(current->error, "Transfer timed out or stalled.");
					temp_item = current->head;
					while (temp_item != NULL) {
						if (strcmp(temp_item->filename_requested, message) == 0) {
							free(temp_item->filename_requested);
							temp_item->filename_requested = NULL;
							reset_checks(0);
							break;
						}
						temp_item = temp_item->next;
					}
					break;
				case 7:
					if ((temp_str = strrchr(message, '/')) != NULL) {
						temp_str++;
						temp_item = current->head;
						while (temp_item != NULL) {
							if (temp_item->status & REQUESTED_FILE &&
							    (strncmp(temp_item->filename_requested, temp_str, strlen(temp_item->filename_requested)) == 0)) {

								log_printf(1, "debug1: Completed transfer of file: %s", temp_item->filename_requested);
								if (use_checksum) {
									temp_item->dest_filename = strdup(message);
									if (temp_item->crc32 == NULL && temp_item->md5 == NULL) {
										log_printf(2, "debug2: no checksums found for: %s. delaying checksumming.",
											   temp_item->filename_requested);
										temp_item->status = COMPLETED;
										temp_item->completed_ts = time(NULL);
									} else {
										log_printf(2, "debug2: found checksums: crc32: %s, md5: %s. checksumming file: %s",
											   (temp_item->crc32 == NULL) ? "" : temp_item->crc32,
											   (temp_item->md5 == NULL) ? "" : temp_item->md5,
											   temp_item->filename_requested);
										pthread_t p_thread;
										pthread_create(&p_thread,
											       NULL,
											       checksum,
											       (void *)create_to_thread(current, remove_query(current, temp_item)));
										
									}
								} else {
									log_printf(2, "debug2: checksumming disabled. destroying object for file: %s",
										   temp_item->filename_requested);
									destroy_query(remove_query(current, temp_item));
								}
								break;
							}
							temp_item = temp_item->next;
						}
					}
				case 8:
					if (current->error_timeout != 0) {
						if (current->error_timeout > 0)
							current->error_timeout--;
						break;
					}
				case 9:
					counter = 0;
					temp_item = current->head;
					while (temp_item != NULL && counter < current->max_requests) {
						if (temp_item->status ^ COMPLETED) {
							if (temp_item->status ^ REQUESTED_FILE) {
								if (!current->is_dcc && !check_conn(temp_item)) {
									offer_dccchat(temp_item);
									/* break out, incase dcc_auto_chat is set, we don't want to 
									 * suddenly start requesting files from the middle of the queue
									 */
									break;
								} else {
									/* request_file returns 0 if the requesting the file wasn't successful */
									temp_item->status |= request_file(temp_item);
								}
							}
							if (temp_item->status & REQUESTED_FILE)
								counter++;
						}
						temp_item = temp_item->next;
					}
					break;
				case 10:
					log_printf(1, "debug1: %s has changed nicks to %s.", current->nick, message);
					free(current->nick);
					current->nick = strndup(message, NICK_MAX);
					break;
				case 11:
					log_printf(1, "debug1: %s has joined.", current->nick);
					if (current->error_timeout == -2)
						reset_checks(0);
					break;
				case 12:
					log_printf(1, "debug1: %s has quit.", current->nick);
					strcpy(current->error, "Nick has quit. Reason: ");
					strncat(current->error, message, ERROR_MAX-25);
					reset_checks(-2);
					break;
				case 13:
					temp_item = current->head;
					while (temp_item != NULL) {
						if (temp_item->status & COMPLETED &&
						    time(NULL) - temp_item->completed_ts > 60) {
							destroy_query(remove_query(current, temp_item));
						}
						temp_item = temp_item->next;
					}
					break;
					
			}
			/* We've found who we're looking for, no reason to keep searching */
			if (source != 8 && source != 13)
				break;
		/* If brain was called from text event "Change Nick", and someone is changing
		   to a nick that we are targeting, we assume this is like someone joining. 
		   Because if someone is switching to a nick that we are targeting, and they had quit,
		   then there's no way someone can join using that nick. */
		} else if (source == 10 && strcasecmp(current->nick, message) == 0) {
			log_printf(1, "debug1: %s has assumed the role of %s.", nick, current->nick);
			if (current->error_timeout == -2)
				reset_checks(0);
			/* we've found a match, lets get out */
			break;
		}
		current = current->next;
	}
	current = current_ptr;

	manage_list_lock(UNLOCK_LIST);
	return 0;
}

void reset_checks(const int timeout) {
	if (timeout == 0)
		current->error[0] = '\0';
	current->error_timeout = timeout;
	struct query *temp_item = current->head;
	/* don't touch items that are already completed and that are transfering */
	while (temp_item != NULL && temp_item->status ^ COMPLETED &&
	       temp_item->filename_requested == NULL) {
		temp_item->status = 0;
		temp_item = temp_item->next;
	}
}
