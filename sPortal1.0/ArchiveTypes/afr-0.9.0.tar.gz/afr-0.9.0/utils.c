/*
 * Automated File Retrieval
 * Copyright (C) 2003 Bailey Kong
 *
 * This file is part of Automated File Retrieval (AFR).
 *
 * AFR is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * AFR is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with AFR; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <glib/gconvert.h>
#include <glib/gmem.h>
#include <stdarg.h>
#include <stdio.h>
#include "afr.h"

void log_printf(const int debug_group, const char *message, ...) {

	if (debug_group == 0)
		xchat_printf(ph, "%s", message);
	if (debug_group <= debug_level) {
		va_list ap;
		int ival;
		const char *ptr;
		char *sval;
		unsigned int hval;
		FILE *file_ptr = fopen(".xchat2/afr.log", "a");
		if (file_ptr != NULL) {
			va_start(ap, message);
			for (ptr = message; *ptr; ptr++) {
				if (*ptr != '%') {
					fputc(*ptr, file_ptr);
					continue;
				}
				switch (*++ptr) {
				case 'c':
					ival = va_arg(ap, int);
					fputc(ival, file_ptr);
					break;
				case 'd':
					ival = va_arg(ap, int);
					fprintf(file_ptr, "%d", ival);
					break;
				case 's':
					for (sval = va_arg(ap, char *); *sval; sval++)
						fputc(*sval, file_ptr);
					break;
				case 'x':
					hval = va_arg(ap, unsigned int);
					fprintf(file_ptr, "0x%08x", hval);
					break;
				default:
					fputc(*ptr, file_ptr);
					break;
				}
			}
			va_end(ap);
			fputc('\n', file_ptr);
			fclose(file_ptr);
		}
	}
}

FILE *wc_fopen(const char *fname, const char *mode) {
        char *locale_fname = g_filename_from_utf8(fname, -1, 0, 0, 0);
        if (locale_fname == NULL)
                return NULL;
        FILE *fp = fopen(locale_fname, mode);
        g_free(locale_fname);
        return fp;
}
